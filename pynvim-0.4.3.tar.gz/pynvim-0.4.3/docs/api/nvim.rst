Nvim Class
==========

An instance of this class is used by remote plugins.

.. autoclass:: pynvim.api.Nvim
   :members:
