Buffer Class
============

.. autoclass:: pynvim.api.Buffer
   :members:
